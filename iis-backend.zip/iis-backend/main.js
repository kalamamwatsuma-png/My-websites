/**
 * IIS LTD Website — main.js
 * Connects the static HTML website to the Node.js backend API.
 * Replace the API_BASE with your deployed server URL when going live.
 */

const API_BASE = 'http://localhost:5000/api';

// ── Sticky nav shadow ─────────────────────────────────────
window.addEventListener('scroll', () => {
  document.querySelector('.nav')?.classList.toggle('scrolled', window.scrollY > 20);
}, { passive: true });

// ── Mobile drawer toggle ──────────────────────────────────
function toggleDrawer() {
  const d = document.getElementById('nav-drawer');
  if (d) d.classList.toggle('open');
}

// ── Page view tracking ────────────────────────────────────
(function trackPageView() {
  const page = location.pathname.split('/').pop() || 'index.html';
  fetch(`${API_BASE}/contact/pageview`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ page })
  }).catch(() => {});
})();

// ── Contact form submission ───────────────────────────────
async function handleSubmit() {
  const name    = document.getElementById('f-name')?.value.trim();
  const email   = document.getElementById('f-email')?.value.trim();
  const msg     = document.getElementById('f-msg')?.value.trim();
  const phone   = document.querySelector('input[type="tel"]')?.value.trim();
  const service = document.querySelector('select.form-control')?.value;

  if (!name || !email || !msg) {
    showFormError('Please fill in Name, Email and Message.');
    return;
  }

  const btn = document.querySelector('.submit-btn');
  if (btn) { btn.textContent = 'Sending…'; btn.disabled = true; }

  try {
    const res = await fetch(`${API_BASE}/contact`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, phone, service, message: msg })
    });

    const data = await res.json();

    if (res.ok) {
      // Show success
      const ok = document.getElementById('form-success');
      if (ok) ok.style.display = 'block';
      // Clear fields
      ['f-name', 'f-email', 'f-msg'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
      });
      if (document.querySelector('input[type="tel"]')) document.querySelector('input[type="tel"]').value = '';
      if (document.querySelector('select.form-control')) document.querySelector('select.form-control').value = '';
    } else {
      const errMsg = data.errors?.[0]?.msg || data.error || 'Submission failed. Please try again.';
      showFormError(errMsg);
    }
  } catch (err) {
    showFormError('Network error. Please check your connection and try again.');
  } finally {
    if (btn) { btn.textContent = 'Send Message →'; btn.disabled = false; }
  }
}

function showFormError(msg) {
  let el = document.getElementById('form-error');
  if (!el) {
    el = document.createElement('div');
    el.id = 'form-error';
    el.className = 'alert alert-error';
    document.querySelector('.submit-btn')?.after(el);
  }
  el.textContent = msg;
  el.style.display = 'block';
  setTimeout(() => { el.style.display = 'none'; }, 5000);
}

// ── Newsletter subscribe (if form present) ────────────────
async function handleSubscribe(email, name = '') {
  try {
    const res = await fetch(`${API_BASE}/contact/subscribe`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, name })
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ── Intersection observer for fade-up animations ──────────
const obs = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) e.target.style.animationPlayState = 'running';
  });
}, { threshold: .15 });

document.querySelectorAll('.fade-up').forEach(el => {
  el.style.animationPlayState = 'paused';
  obs.observe(el);
});
