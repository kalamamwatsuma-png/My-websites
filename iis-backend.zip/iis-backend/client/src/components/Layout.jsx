import { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const NAV = [
  { to: '/', label: 'Dashboard', icon: '⊞', end: true },
  { to: '/enquiries', label: 'Enquiries', icon: '✉' },
  { to: '/subscribers', label: 'Subscribers', icon: '👥' },
  { to: '/settings', label: 'Settings', icon: '⚙' },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/login'); };

  return (
    <div style={s.shell}>
      {/* Sidebar */}
      <aside style={{ ...s.sidebar, transform: sidebarOpen ? 'translateX(0)' : undefined }}>
        <div style={s.sideTop}>
          <div style={s.brand}>
            <div style={s.brandMark}>IIS</div>
            <div>
              <div style={s.brandName}>IIS LTD</div>
              <div style={s.brandSub}>Admin Panel</div>
            </div>
          </div>
          <nav style={s.nav}>
            {NAV.map(n => (
              <NavLink key={n.to} to={n.to} end={n.end} style={({ isActive }) => ({ ...s.navLink, ...(isActive ? s.navActive : {}) })}
                onClick={() => setSidebarOpen(false)}>
                <span style={s.navIcon}>{n.icon}</span>
                {n.label}
              </NavLink>
            ))}
          </nav>
        </div>
        <div style={s.sideBot}>
          <a href="http://localhost:5173" target="_blank" rel="noopener" style={s.extLink}>🌐 View Website</a>
          <div style={s.userRow}>
            <div style={s.avatar}>{user?.username?.[0]?.toUpperCase()}</div>
            <div style={s.userInfo}>
              <div style={s.userName}>{user?.username}</div>
              <div style={s.userRole}>{user?.role}</div>
            </div>
            <button onClick={handleLogout} style={s.logoutBtn} title="Sign out">⏻</button>
          </div>
        </div>
      </aside>

      {/* Mobile overlay */}
      {sidebarOpen && <div style={s.overlay} onClick={() => setSidebarOpen(false)} />}

      {/* Main */}
      <div style={s.main}>
        {/* Topbar */}
        <header style={s.topbar}>
          <button style={s.menuBtn} onClick={() => setSidebarOpen(o => !o)}>☰</button>
          <div style={s.topRight}>
            <span style={s.topUser}>👤 {user?.username}</span>
            <button onClick={handleLogout} style={s.topLogout}>Sign Out</button>
          </div>
        </header>
        <div style={s.content}>
          <Outlet />
        </div>
      </div>
    </div>
  );
}

const s = {
  shell: { display: 'flex', minHeight: '100vh', background: 'var(--gray-50)' },
  sidebar: { width: 'var(--sidebar-w)', background: 'var(--navy-deep)', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', position: 'sticky', top: 0, height: '100vh', flexShrink: 0, zIndex: 100 },
  sideTop: { padding: '1.5rem 0 0' },
  brand: { display: 'flex', alignItems: 'center', gap: 10, padding: '0 1.25rem 1.5rem', borderBottom: '1px solid rgba(255,255,255,.08)' },
  brandMark: { width: 38, height: 38, background: 'var(--crimson)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Syne,sans-serif', fontWeight: 800, fontSize: 12, color: '#fff', flexShrink: 0 },
  brandName: { fontFamily: 'Syne,sans-serif', fontSize: 13, fontWeight: 700, color: '#fff' },
  brandSub: { fontSize: 11, color: 'rgba(255,255,255,.35)' },
  nav: { display: 'flex', flexDirection: 'column', padding: '1rem 0.75rem', gap: 2 },
  navLink: { display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px', borderRadius: 8, color: 'rgba(255,255,255,.6)', fontSize: 14, fontWeight: 500, transition: 'all .18s', textDecoration: 'none' },
  navActive: { background: 'rgba(255,255,255,.12)', color: '#fff' },
  navIcon: { fontSize: 15, width: 20, textAlign: 'center' },
  sideBot: { padding: '1rem 0.75rem 1.25rem', borderTop: '1px solid rgba(255,255,255,.08)' },
  extLink: { display: 'block', fontSize: 12.5, color: 'rgba(255,255,255,.4)', padding: '6px 8px', marginBottom: 8, textDecoration: 'none' },
  userRow: { display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', background: 'rgba(255,255,255,.06)', borderRadius: 8 },
  avatar: { width: 30, height: 30, background: 'var(--navy-mid)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontFamily: 'Syne,sans-serif', fontWeight: 700, fontSize: 12, flexShrink: 0 },
  userInfo: { flex: 1, minWidth: 0 },
  userName: { fontSize: 12.5, fontWeight: 600, color: '#fff', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  userRole: { fontSize: 11, color: 'rgba(255,255,255,.35)' },
  logoutBtn: { background: 'none', border: 'none', color: 'rgba(255,255,255,.4)', fontSize: 16, cursor: 'pointer', padding: 2 },
  overlay: { position: 'fixed', inset: 0, background: 'rgba(0,0,0,.5)', zIndex: 99 },
  main: { flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 },
  topbar: { height: 56, background: '#fff', borderBottom: '1px solid var(--gray-200)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 1.5rem', position: 'sticky', top: 0, zIndex: 50, boxShadow: 'var(--shadow-sm)' },
  menuBtn: { background: 'none', border: 'none', fontSize: 20, color: 'var(--navy)', display: 'none', cursor: 'pointer' },
  topRight: { display: 'flex', alignItems: 'center', gap: 12 },
  topUser: { fontSize: 13.5, color: 'var(--gray-600)', fontWeight: 500 },
  topLogout: { background: 'var(--gray-100)', border: 'none', borderRadius: 6, padding: '6px 12px', fontSize: 13, cursor: 'pointer', color: 'var(--gray-600)', fontWeight: 500 },
  content: { flex: 1, padding: '2rem', overflowY: 'auto' },
};
