import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function Login() {
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(form.username, form.password);
      navigate('/');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        {/* Logo area */}
        <div style={styles.logoArea}>
          <div style={styles.logoMark}>IIS</div>
          <div>
            <div style={styles.logoTitle}>Identity Insight Solution Ltd</div>
            <div style={styles.logoSub}>Admin Dashboard</div>
          </div>
        </div>

        <h1 style={styles.heading}>Sign In</h1>
        <p style={styles.sub}>Enter your credentials to access the dashboard.</p>

        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.group}>
            <label style={styles.label}>Username or Email</label>
            <input
              style={styles.input}
              type="text"
              placeholder="admin"
              value={form.username}
              onChange={e => setForm(f => ({ ...f, username: e.target.value }))}
              required
              autoFocus
            />
          </div>
          <div style={styles.group}>
            <label style={styles.label}>Password</label>
            <input
              style={styles.input}
              type="password"
              placeholder="••••••••"
              value={form.password}
              onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
              required
            />
          </div>
          {error && <div style={styles.error}>{error}</div>}
          <button style={{ ...styles.btn, opacity: loading ? 0.7 : 1 }} type="submit" disabled={loading}>
            {loading ? 'Signing in…' : 'Sign In →'}
          </button>
        </form>

        <div style={styles.hint}>
          Default credentials: <strong>admin</strong> / <strong>Admin@IIS2026</strong>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: { minHeight: '100vh', background: 'linear-gradient(135deg, #1a2a6c 0%, #2e4090 60%, #b22222 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' },
  card: { background: '#fff', borderRadius: 20, padding: '2.5rem', width: '100%', maxWidth: 420, boxShadow: '0 20px 60px rgba(0,0,0,.25)' },
  logoArea: { display: 'flex', alignItems: 'center', gap: 14, marginBottom: '2rem', paddingBottom: '1.5rem', borderBottom: '1px solid #f1f5f9' },
  logoMark: { width: 48, height: 48, background: '#1a2a6c', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 14, flexShrink: 0 },
  logoTitle: { fontFamily: 'Syne, sans-serif', fontSize: 13, fontWeight: 700, color: '#1a2a6c', lineHeight: 1.3 },
  logoSub: { fontSize: 11, color: '#94a3b8', marginTop: 2 },
  heading: { fontFamily: 'Syne, sans-serif', fontSize: 24, fontWeight: 800, color: '#0f172a', marginBottom: 6 },
  sub: { fontSize: 14, color: '#64748b', marginBottom: '1.75rem', lineHeight: 1.6 },
  form: { display: 'flex', flexDirection: 'column', gap: '1rem' },
  group: { display: 'flex', flexDirection: 'column', gap: 6 },
  label: { fontSize: 13, fontWeight: 500, color: '#475569' },
  input: { padding: '10px 14px', border: '1.5px solid #e2e8f0', borderRadius: 8, fontSize: 14, color: '#0f172a', outline: 'none', transition: 'border .2s', fontFamily: 'DM Sans, sans-serif' },
  error: { background: '#fee2e2', color: '#991b1b', fontSize: 13.5, padding: '10px 14px', borderRadius: 8, border: '1px solid #fca5a5' },
  btn: { background: '#1a2a6c', color: '#fff', border: 'none', padding: '13px', borderRadius: 8, fontFamily: 'Syne, sans-serif', fontSize: 15, fontWeight: 700, cursor: 'pointer', marginTop: 4, transition: 'background .2s' },
  hint: { marginTop: '1.5rem', padding: '12px 14px', background: '#f8fafc', borderRadius: 8, fontSize: 12.5, color: '#64748b', textAlign: 'center', border: '1px solid #e2e8f0', lineHeight: 1.6 }
};
