import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

function Section({ title, sub, children }) {
  return (
    <div style={{ background: '#fff', borderRadius: 14, border: '1px solid var(--gray-200)', padding: '1.75rem', boxShadow: 'var(--shadow-sm)', marginBottom: '1.5rem' }}>
      <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 16, fontWeight: 700, color: 'var(--navy)', marginBottom: 4 }}>{title}</div>
      {sub && <div style={{ fontSize: 13.5, color: 'var(--gray-400)', marginBottom: '1.25rem' }}>{sub}</div>}
      {children}
    </div>
  );
}

function Toast({ msg, type }) {
  if (!msg) return null;
  const bg = type === 'error' ? '#fee2e2' : '#dcfce7';
  const color = type === 'error' ? '#991b1b' : '#166534';
  return <div style={{ background: bg, color, borderRadius: 8, padding: '10px 14px', fontSize: 13.5, marginBottom: '1rem', border: `1px solid ${type === 'error' ? '#fca5a5' : '#86efac'}` }}>{msg}</div>;
}

export default function Settings() {
  const { user, authFetch } = useAuth();
  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [pwMsg, setPwMsg] = useState({ msg: '', type: '' });
  const [pwLoading, setPwLoading] = useState(false);

  const [users, setUsers] = useState([]);
  const [newUser, setNewUser] = useState({ username: '', email: '', password: '', role: 'admin' });
  const [userMsg, setUserMsg] = useState({ msg: '', type: '' });
  const [userLoading, setUserLoading] = useState(false);

  const fetchUsers = () => {
    authFetch('/api/admin/users').then(r => r.json()).then(setUsers).catch(() => {});
  };

  useEffect(() => { fetchUsers(); }, []);

  const changePassword = async () => {
    if (!pwForm.currentPassword || !pwForm.newPassword) return setPwMsg({ msg: 'All fields required.', type: 'error' });
    if (pwForm.newPassword !== pwForm.confirm) return setPwMsg({ msg: 'New passwords do not match.', type: 'error' });
    if (pwForm.newPassword.length < 8) return setPwMsg({ msg: 'New password must be at least 8 characters.', type: 'error' });
    setPwLoading(true);
    try {
      const res = await authFetch('/api/auth/change-password', { method: 'POST', body: JSON.stringify({ currentPassword: pwForm.currentPassword, newPassword: pwForm.newPassword }) });
      const d = await res.json();
      if (!res.ok) setPwMsg({ msg: d.error, type: 'error' });
      else { setPwMsg({ msg: 'Password updated successfully!', type: 'success' }); setPwForm({ currentPassword: '', newPassword: '', confirm: '' }); }
    } catch { setPwMsg({ msg: 'Failed to update password.', type: 'error' }); }
    finally { setPwLoading(false); }
  };

  const createUser = async () => {
    if (!newUser.username || !newUser.email || !newUser.password) return setUserMsg({ msg: 'All fields required.', type: 'error' });
    setUserLoading(true);
    try {
      const res = await authFetch('/api/admin/users', { method: 'POST', body: JSON.stringify(newUser) });
      const d = await res.json();
      if (!res.ok) setUserMsg({ msg: d.error, type: 'error' });
      else { setUserMsg({ msg: `User "${newUser.username}" created.`, type: 'success' }); setNewUser({ username: '', email: '', password: '', role: 'admin' }); fetchUsers(); }
    } catch { setUserMsg({ msg: 'Failed to create user.', type: 'error' }); }
    finally { setUserLoading(false); }
  };

  const deleteUser = async (id, username) => {
    if (!confirm(`Delete user "${username}"?`)) return;
    await authFetch(`/api/admin/users/${id}`, { method: 'DELETE' });
    fetchUsers();
  };

  return (
    <div style={{ maxWidth: 720 }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ fontFamily: 'Syne,sans-serif', fontSize: 26, fontWeight: 800, color: 'var(--navy)' }}>Settings</h1>
        <p style={{ color: 'var(--gray-400)', fontSize: 14, marginTop: 4 }}>Manage your account and admin users.</p>
      </div>

      {/* Account info */}
      <Section title="Your Account" sub="Current session details.">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
          <InfoRow label="Username" value={user?.username} />
          <InfoRow label="Email" value={user?.email} />
          <InfoRow label="Role" value={user?.role} />
          <InfoRow label="Last Login" value={user?.last_login ? new Date(user.last_login).toLocaleString() : 'N/A'} />
        </div>
      </Section>

      {/* Change password */}
      <Section title="Change Password" sub="Use a strong password with at least 8 characters.">
        <Toast msg={pwMsg.msg} type={pwMsg.type} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.9rem' }}>
          <FormGroup label="Current Password">
            <input style={inputStyle} type="password" placeholder="••••••••" value={pwForm.currentPassword} onChange={e => setPwForm(f => ({ ...f, currentPassword: e.target.value }))} />
          </FormGroup>
          <FormGroup label="New Password">
            <input style={inputStyle} type="password" placeholder="Min 8 characters" value={pwForm.newPassword} onChange={e => setPwForm(f => ({ ...f, newPassword: e.target.value }))} />
          </FormGroup>
          <FormGroup label="Confirm New Password">
            <input style={inputStyle} type="password" placeholder="Repeat new password" value={pwForm.confirm} onChange={e => setPwForm(f => ({ ...f, confirm: e.target.value }))} />
          </FormGroup>
          <button onClick={changePassword} disabled={pwLoading} style={primaryBtn}>{pwLoading ? 'Updating…' : 'Update Password'}</button>
        </div>
      </Section>

      {/* Admin users */}
      <Section title="Admin Users" sub="Manage who has access to this dashboard.">
        <Toast msg={userMsg.msg} type={userMsg.type} />
        {users.length > 0 && (
          <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '1.5rem' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--gray-200)' }}>
                {['Username', 'Email', 'Role', 'Last Login', ''].map(h => (
                  <th key={h} style={{ padding: '8px 10px', fontSize: 11, fontWeight: 700, color: 'var(--gray-400)', textTransform: 'uppercase', letterSpacing: '.05em', textAlign: 'left' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id} style={{ borderTop: '1px solid var(--gray-100)' }}>
                  <td style={{ padding: '9px 10px', fontSize: 13.5, fontWeight: 600 }}>{u.username}</td>
                  <td style={{ padding: '9px 10px', fontSize: 13, color: 'var(--gray-600)' }}>{u.email}</td>
                  <td style={{ padding: '9px 10px' }}>
                    <span style={{ background: '#dbeafe', color: '#1d4ed8', fontSize: 11.5, fontWeight: 700, padding: '2px 8px', borderRadius: 20 }}>{u.role}</span>
                  </td>
                  <td style={{ padding: '9px 10px', fontSize: 12, color: 'var(--gray-400)' }}>{u.last_login ? new Date(u.last_login).toLocaleDateString() : '—'}</td>
                  <td style={{ padding: '9px 10px' }}>
                    {u.id !== user?.id && (
                      <button onClick={() => deleteUser(u.id, u.username)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--gray-400)', fontSize: 15 }}>🗑</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* Add new user */}
        <div style={{ borderTop: '1px solid var(--gray-200)', paddingTop: '1.25rem' }}>
          <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 13.5, fontWeight: 700, color: 'var(--navy)', marginBottom: '1rem' }}>Add New Admin User</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '0.75rem' }}>
            <input style={inputStyle} placeholder="Username" value={newUser.username} onChange={e => setNewUser(f => ({ ...f, username: e.target.value }))} />
            <input style={inputStyle} type="email" placeholder="Email address" value={newUser.email} onChange={e => setNewUser(f => ({ ...f, email: e.target.value }))} />
            <input style={inputStyle} type="password" placeholder="Password" value={newUser.password} onChange={e => setNewUser(f => ({ ...f, password: e.target.value }))} />
            <select style={inputStyle} value={newUser.role} onChange={e => setNewUser(f => ({ ...f, role: e.target.value }))}>
              <option value="admin">Admin</option>
              <option value="superadmin">Superadmin</option>
            </select>
          </div>
          <button onClick={createUser} disabled={userLoading} style={primaryBtn}>{userLoading ? 'Creating…' : '+ Create User'}</button>
        </div>
      </Section>

      {/* API info */}
      <Section title="API Endpoints" sub="Connect your website to these backend endpoints.">
        {[
          ['POST', '/api/contact', 'Submit contact form (name, email, message, phone?, service?)'],
          ['POST', '/api/contact/subscribe', 'Newsletter subscribe (email, name?)'],
          ['POST', '/api/contact/pageview', 'Track page view (page)'],
          ['POST', '/api/auth/login', 'Admin login (username, password)'],
          ['GET', '/api/enquiries', 'List enquiries (auth required)'],
          ['GET', '/api/admin/stats', 'Dashboard stats (auth required)'],
          ['GET', '/api/health', 'Health check'],
        ].map(([method, path, desc]) => (
          <div key={path} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', padding: '8px 0', borderBottom: '1px solid var(--gray-100)', fontSize: 13 }}>
            <span style={{ background: method === 'GET' ? '#dbeafe' : '#fef3c7', color: method === 'GET' ? '#1d4ed8' : '#92400e', fontWeight: 700, fontSize: 11, padding: '2px 7px', borderRadius: 4, fontFamily: 'monospace', flexShrink: 0 }}>{method}</span>
            <code style={{ color: 'var(--navy)', fontFamily: 'monospace', fontSize: 12.5, flexShrink: 0 }}>{path}</code>
            <span style={{ color: 'var(--gray-400)', fontSize: 12 }}>{desc}</span>
          </div>
        ))}
      </Section>
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div style={{ background: 'var(--gray-50)', borderRadius: 8, padding: '10px 14px', border: '1px solid var(--gray-200)' }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--gray-400)', textTransform: 'uppercase', letterSpacing: '.05em', marginBottom: 3 }}>{label}</div>
      <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--gray-900)' }}>{value}</div>
    </div>
  );
}

function FormGroup({ label, children }) {
  return (
    <div>
      <label style={{ display: 'block', fontSize: 13, fontWeight: 500, color: 'var(--gray-600)', marginBottom: 5 }}>{label}</label>
      {children}
    </div>
  );
}

const inputStyle = { width: '100%', padding: '9px 13px', border: '1.5px solid var(--gray-200)', borderRadius: 8, fontSize: 13.5, color: 'var(--gray-900)', outline: 'none', fontFamily: 'DM Sans, sans-serif', background: '#fff' };
const primaryBtn = { background: 'var(--navy)', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 22px', fontFamily: 'Syne,sans-serif', fontSize: 14, fontWeight: 700, cursor: 'pointer', width: '100%', marginTop: 4 };
