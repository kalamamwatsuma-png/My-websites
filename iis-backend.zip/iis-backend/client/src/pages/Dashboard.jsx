import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, LineChart, Line, CartesianGrid
} from 'recharts';

const STATUS_COLORS = { new: '#3b82f6', in_progress: '#f59e0b', replied: '#16a34a', closed: '#94a3b8' };
const PIE_COLORS = ['#1a2a6c', '#b22222', '#16a34a', '#f0c040', '#2e4090', '#64748b'];

function StatCard({ label, value, sub, color = '#1a2a6c', icon }) {
  return (
    <div style={{ background: '#fff', border: '1px solid var(--gray-200)', borderRadius: 14, padding: '1.5rem', display: 'flex', gap: 16, alignItems: 'center', boxShadow: 'var(--shadow-sm)' }}>
      <div style={{ width: 52, height: 52, background: color + '18', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, flexShrink: 0 }}>{icon}</div>
      <div>
        <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 28, fontWeight: 800, color, lineHeight: 1 }}>{value}</div>
        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--gray-600)', marginTop: 4 }}>{label}</div>
        {sub && <div style={{ fontSize: 11.5, color: 'var(--gray-400)', marginTop: 2 }}>{sub}</div>}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { authFetch } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    authFetch('/api/admin/stats')
      .then(r => r.json())
      .then(d => { setStats(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  if (loading) return <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--gray-400)' }}>Loading dashboard…</div>;
  if (!stats) return <div style={{ padding: '3rem', textAlign: 'center', color: 'red' }}>Failed to load stats.</div>;

  const { summary, recentEnquiries, topPages, enquiriesByService, enquiriesByDay } = stats;

  const statusData = [
    { name: 'New', value: summary.new, color: '#3b82f6' },
    { name: 'Replied', value: summary.replied, color: '#16a34a' },
    { name: 'Closed', value: summary.closed, color: '#94a3b8' },
  ].filter(d => d.value > 0);

  return (
    <div>
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontFamily: 'Syne,sans-serif', fontSize: 26, fontWeight: 800, color: 'var(--navy)' }}>Dashboard</h1>
        <p style={{ color: 'var(--gray-400)', fontSize: 14, marginTop: 4 }}>Welcome back. Here's what's happening at IIS LTD.</p>
      </div>

      {/* Stats grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', marginBottom: '2rem' }}>
        <StatCard label="Total Enquiries" value={summary.total} icon="✉️" color="#1a2a6c" sub="All time" />
        <StatCard label="New Enquiries" value={summary.new} icon="🔔" color="#3b82f6" sub="Awaiting response" />
        <StatCard label="Replied" value={summary.replied} icon="✅" color="#16a34a" sub="Responded to" />
        <StatCard label="Subscribers" value={summary.subscribers} icon="👥" color="#b22222" sub="Newsletter" />
        <StatCard label="Page Views" value={summary.pageViews} icon="👁️" color="#7c3aed" sub="Total tracked" />
      </div>

      {/* Charts row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem', marginBottom: '1.5rem' }}>

        {/* Enquiries over time */}
        <div style={cardStyle}>
          <div style={cardTitle}>Enquiries (Last 30 Days)</div>
          {enquiriesByDay.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={enquiriesByDay} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={d => d.slice(5)} />
                <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                <Tooltip formatter={(v) => [v, 'Enquiries']} labelFormatter={l => `Date: ${l}`} />
                <Line type="monotone" dataKey="count" stroke="#1a2a6c" strokeWidth={2.5} dot={{ fill: '#1a2a6c', r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div style={emptyMsg}>No enquiry data yet</div>
          )}
        </div>

        {/* Enquiries by service */}
        <div style={cardStyle}>
          <div style={cardTitle}>Enquiries by Service</div>
          {enquiriesByService.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={enquiriesByService} dataKey="count" nameKey="service" cx="50%" cy="50%" outerRadius={70} label={({ service, percent }) => `${(percent * 100).toFixed(0)}%`} labelLine={false}>
                  {enquiriesByService.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v, n, p) => [v, p.payload.service]} />
                <Legend formatter={(v, entry) => entry.payload.service} iconSize={10} wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div style={emptyMsg}>No service data yet</div>
          )}
        </div>
      </div>

      {/* Bottom row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: '1.5rem' }}>

        {/* Recent enquiries */}
        <div style={cardStyle}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <div style={cardTitle}>Recent Enquiries</div>
            <button onClick={() => navigate('/enquiries')} style={viewAllBtn}>View All →</button>
          </div>
          {recentEnquiries.length === 0 ? (
            <div style={emptyMsg}>No enquiries yet</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {recentEnquiries.map(e => (
                <div key={e.id} onClick={() => navigate('/enquiries')} style={enquiryRow}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--gray-900)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{e.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--gray-400)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{e.email}</div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
                    <span style={{ ...statusBadge, background: (STATUS_COLORS[e.status] || '#ccc') + '20', color: STATUS_COLORS[e.status] || '#666' }}>{e.status}</span>
                    <span style={{ fontSize: 11, color: 'var(--gray-400)' }}>{new Date(e.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Top pages */}
        <div style={cardStyle}>
          <div style={cardTitle}>Top Pages Visited</div>
          {topPages.length === 0 ? (
            <div style={emptyMsg}>No page view data yet</div>
          ) : (
            <div style={{ marginTop: '0.5rem' }}>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={topPages} layout="vertical" margin={{ left: 10, right: 20 }}>
                  <XAxis type="number" tick={{ fontSize: 11 }} />
                  <YAxis type="category" dataKey="page" tick={{ fontSize: 11 }} width={80} />
                  <Tooltip />
                  <Bar dataKey="views" fill="#2e4090" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

const cardStyle = { background: '#fff', border: '1px solid var(--gray-200)', borderRadius: 14, padding: '1.5rem', boxShadow: 'var(--shadow-sm)' };
const cardTitle = { fontFamily: 'Syne,sans-serif', fontSize: 14, fontWeight: 700, color: 'var(--navy)', marginBottom: '0.75rem' };
const emptyMsg = { textAlign: 'center', color: 'var(--gray-400)', fontSize: 13, padding: '2rem 0' };
const enquiryRow = { display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', borderRadius: 8, cursor: 'pointer', border: '1px solid var(--gray-100)', transition: 'background .15s' };
const statusBadge = { fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 20, textTransform: 'capitalize', whiteSpace: 'nowrap' };
const viewAllBtn = { background: 'none', border: '1px solid var(--gray-200)', borderRadius: 6, padding: '5px 12px', fontSize: 12.5, cursor: 'pointer', color: 'var(--navy)', fontWeight: 500 };
