import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

const STATUS_OPTIONS = ['all', 'new', 'in_progress', 'replied', 'closed'];
const STATUS_COLORS = { new: '#3b82f6', in_progress: '#f59e0b', replied: '#16a34a', closed: '#94a3b8' };
const STATUS_BG = { new: '#dbeafe', in_progress: '#fef3c7', replied: '#dcfce7', closed: '#f1f5f9' };

function StatusBadge({ status }) {
  return (
    <span style={{ background: STATUS_BG[status] || '#f1f5f9', color: STATUS_COLORS[status] || '#666', fontSize: 11.5, fontWeight: 700, padding: '3px 10px', borderRadius: 20, textTransform: 'capitalize', whiteSpace: 'nowrap' }}>
      {status?.replace('_', ' ')}
    </span>
  );
}

export default function Enquiries() {
  const { authFetch } = useAuth();
  const [data, setData] = useState({ enquiries: [], total: 0 });
  const [filters, setFilters] = useState({ status: 'all', search: '', page: 1 });
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);

  const fetchEnquiries = () => {
    setLoading(true);
    const params = new URLSearchParams({ status: filters.status, search: filters.search, page: filters.page, limit: 15 });
    authFetch(`/api/enquiries?${params}`)
      .then(r => r.json())
      .then(d => { setData(d); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(() => { fetchEnquiries(); }, [filters]);

  const updateStatus = async (id, status) => {
    setUpdating(true);
    await authFetch(`/api/enquiries/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
    setUpdating(false);
    fetchEnquiries();
    if (selected?.id === id) setSelected(s => ({ ...s, status }));
  };

  const deleteEnquiry = async (id) => {
    if (!confirm('Delete this enquiry?')) return;
    await authFetch(`/api/enquiries/${id}`, { method: 'DELETE' });
    if (selected?.id === id) setSelected(null);
    fetchEnquiries();
  };

  const totalPages = Math.ceil(data.total / 15);

  return (
    <div>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={pageTitle}>Enquiries</h1>
        <p style={pageSub}>Manage contact form submissions from the website.</p>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.25rem', flexWrap: 'wrap', alignItems: 'center' }}>
        <input
          style={inputStyle}
          placeholder="Search name, email, message..."
          value={filters.search}
          onChange={e => setFilters(f => ({ ...f, search: e.target.value, page: 1 }))}
        />
        <div style={{ display: 'flex', gap: 6 }}>
          {STATUS_OPTIONS.map(s => (
            <button key={s} onClick={() => setFilters(f => ({ ...f, status: s, page: 1 }))}
              style={{ ...filterBtn, ...(filters.status === s ? filterBtnActive : {}) }}>
              {s === 'all' ? 'All' : s.replace('_', ' ')}
            </button>
          ))}
        </div>
        <span style={{ fontSize: 13, color: 'var(--gray-400)', marginLeft: 'auto' }}>{data.total} total</span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: selected ? '1fr 380px' : '1fr', gap: '1.5rem' }}>
        {/* Table */}
        <div style={{ background: '#fff', borderRadius: 14, border: '1px solid var(--gray-200)', overflow: 'hidden', boxShadow: 'var(--shadow-sm)' }}>
          {loading ? (
            <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--gray-400)' }}>Loading…</div>
          ) : data.enquiries.length === 0 ? (
            <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--gray-400)' }}>No enquiries found.</div>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--gray-200)', background: 'var(--gray-50)' }}>
                  {['Name', 'Email', 'Service', 'Status', 'Date', ''].map(h => (
                    <th key={h} style={thStyle}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.enquiries.map(e => (
                  <tr key={e.id}
                    onClick={() => setSelected(e)}
                    style={{ ...trStyle, background: selected?.id === e.id ? '#f0f4ff' : '#fff' }}>
                    <td style={tdStyle}><span style={{ fontWeight: 600, fontSize: 14 }}>{e.name}</span></td>
                    <td style={tdStyle}><span style={{ fontSize: 13, color: 'var(--gray-600)' }}>{e.email}</span></td>
                    <td style={tdStyle}><span style={{ fontSize: 12.5, color: 'var(--gray-400)' }}>{e.service || '—'}</span></td>
                    <td style={tdStyle}><StatusBadge status={e.status} /></td>
                    <td style={tdStyle}><span style={{ fontSize: 12, color: 'var(--gray-400)' }}>{new Date(e.created_at).toLocaleDateString()}</span></td>
                    <td style={tdStyle} onClick={ev => ev.stopPropagation()}>
                      <button onClick={() => deleteEnquiry(e.id)} style={dangerBtn} title="Delete">🗑</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div style={{ display: 'flex', justifyContent: 'center', gap: 8, padding: '1rem', borderTop: '1px solid var(--gray-200)' }}>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
                <button key={p} onClick={() => setFilters(f => ({ ...f, page: p }))}
                  style={{ ...filterBtn, ...(filters.page === p ? filterBtnActive : {}), minWidth: 36 }}>
                  {p}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Detail panel */}
        {selected && (
          <div style={{ background: '#fff', borderRadius: 14, border: '1px solid var(--gray-200)', padding: '1.5rem', boxShadow: 'var(--shadow-sm)', alignSelf: 'start', position: 'sticky', top: '1rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
              <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 15, fontWeight: 700, color: 'var(--navy)' }}>Enquiry #{selected.id}</div>
              <button onClick={() => setSelected(null)} style={{ background: 'none', border: 'none', fontSize: 18, cursor: 'pointer', color: 'var(--gray-400)' }}>✕</button>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.9rem', marginBottom: '1.25rem' }}>
              <Field label="Name" value={selected.name} />
              <Field label="Email" value={<a href={`mailto:${selected.email}`} style={{ color: 'var(--navy)' }}>{selected.email}</a>} />
              {selected.phone && <Field label="Phone" value={<a href={`tel:${selected.phone}`} style={{ color: 'var(--navy)' }}>{selected.phone}</a>} />}
              {selected.service && <Field label="Service" value={selected.service} />}
              <Field label="Date" value={new Date(selected.created_at).toLocaleString()} />
              <Field label="Status" value={<StatusBadge status={selected.status} />} />
            </div>

            <div style={{ background: 'var(--gray-50)', borderRadius: 8, padding: '1rem', fontSize: 14, color: 'var(--gray-600)', lineHeight: 1.7, marginBottom: '1.25rem', border: '1px solid var(--gray-200)' }}>
              <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--gray-400)', textTransform: 'uppercase', letterSpacing: '.05em', marginBottom: 6 }}>Message</div>
              {selected.message}
            </div>

            {/* Status update */}
            <div style={{ marginBottom: '1rem' }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--gray-400)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '.05em' }}>Update Status</div>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {['new', 'in_progress', 'replied', 'closed'].map(st => (
                  <button key={st} disabled={updating || selected.status === st}
                    onClick={() => updateStatus(selected.id, st)}
                    style={{ ...filterBtn, ...(selected.status === st ? filterBtnActive : {}), fontSize: 12, opacity: updating ? 0.6 : 1 }}>
                    {st.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick actions */}
            <div style={{ display: 'flex', gap: 8 }}>
              <a href={`mailto:${selected.email}?subject=Re: Your enquiry to IIS LTD`}
                style={{ flex: 1, background: 'var(--navy)', color: '#fff', borderRadius: 8, padding: '9px 0', textAlign: 'center', fontSize: 13, fontWeight: 600, fontFamily: 'Syne,sans-serif', textDecoration: 'none' }}>
                ✉ Reply by Email
              </a>
              {selected.phone && (
                <a href={`https://wa.me/${selected.phone.replace(/\D/g, '')}`} target="_blank" rel="noopener"
                  style={{ flex: 1, background: '#16a34a', color: '#fff', borderRadius: 8, padding: '9px 0', textAlign: 'center', fontSize: 13, fontWeight: 600, fontFamily: 'Syne,sans-serif', textDecoration: 'none' }}>
                  💬 WhatsApp
                </a>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, value }) {
  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--gray-400)', textTransform: 'uppercase', letterSpacing: '.05em', marginBottom: 3 }}>{label}</div>
      <div style={{ fontSize: 14, color: 'var(--gray-900)' }}>{value}</div>
    </div>
  );
}

const pageTitle = { fontFamily: 'Syne,sans-serif', fontSize: 26, fontWeight: 800, color: 'var(--navy)' };
const pageSub = { color: 'var(--gray-400)', fontSize: 14, marginTop: 4 };
const inputStyle = { padding: '8px 14px', border: '1.5px solid var(--gray-200)', borderRadius: 8, fontSize: 13.5, outline: 'none', minWidth: 260 };
const filterBtn = { background: 'var(--gray-100)', border: '1px solid var(--gray-200)', borderRadius: 6, padding: '6px 12px', fontSize: 12.5, cursor: 'pointer', color: 'var(--gray-600)', fontWeight: 500, textTransform: 'capitalize', transition: 'all .15s' };
const filterBtnActive = { background: 'var(--navy)', color: '#fff', borderColor: 'var(--navy)' };
const thStyle = { padding: '11px 14px', fontSize: 11.5, fontWeight: 700, color: 'var(--gray-400)', textTransform: 'uppercase', letterSpacing: '.05em', textAlign: 'left' };
const tdStyle = { padding: '11px 14px', borderTop: '1px solid var(--gray-100)' };
const trStyle = { cursor: 'pointer', transition: 'background .15s' };
const dangerBtn = { background: 'none', border: 'none', cursor: 'pointer', fontSize: 15, color: 'var(--gray-400)', padding: 4, borderRadius: 4 };
