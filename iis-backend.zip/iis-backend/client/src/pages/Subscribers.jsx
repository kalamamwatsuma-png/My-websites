import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

export default function Subscribers() {
  const { authFetch } = useAuth();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const fetch = () => {
    setLoading(true);
    authFetch('/api/admin/subscribers')
      .then(r => r.json())
      .then(d => { setRows(d); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(() => { fetch(); }, []);

  const del = async (id) => {
    if (!confirm('Remove this subscriber?')) return;
    await authFetch(`/api/admin/subscribers/${id}`, { method: 'DELETE' });
    fetch();
  };

  const filtered = rows.filter(r =>
    r.email.toLowerCase().includes(search.toLowerCase()) ||
    (r.name || '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={pageTitle}>Newsletter Subscribers</h1>
        <p style={pageSub}>{rows.length} total subscriber{rows.length !== 1 ? 's' : ''}.</p>
      </div>

      <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.25rem', alignItems: 'center' }}>
        <input
          style={{ padding: '8px 14px', border: '1.5px solid var(--gray-200)', borderRadius: 8, fontSize: 13.5, outline: 'none', minWidth: 280 }}
          placeholder="Search subscribers..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <button onClick={() => {
          const csv = ['Email,Name,Date', ...rows.map(r => `${r.email},${r.name || ''},${r.subscribed_at}`)].join('\n');
          const blob = new Blob([csv], { type: 'text/csv' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a'); a.href = url; a.download = 'subscribers.csv'; a.click();
        }} style={{ background: 'var(--navy)', color: '#fff', border: 'none', borderRadius: 8, padding: '8px 16px', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'Syne,sans-serif' }}>
          ⬇ Export CSV
        </button>
      </div>

      <div style={{ background: '#fff', borderRadius: 14, border: '1px solid var(--gray-200)', overflow: 'hidden', boxShadow: 'var(--shadow-sm)' }}>
        {loading ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--gray-400)' }}>Loading…</div>
        ) : filtered.length === 0 ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--gray-400)' }}>
            {rows.length === 0 ? 'No subscribers yet. They come from the newsletter sign-up on the website.' : 'No results for your search.'}
          </div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--gray-200)', background: 'var(--gray-50)' }}>
                {['#', 'Email', 'Name', 'Subscribed', 'Status', ''].map(h => (
                  <th key={h} style={thStyle}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((r, i) => (
                <tr key={r.id} style={{ borderTop: '1px solid var(--gray-100)' }}>
                  <td style={tdStyle}><span style={{ fontSize: 12, color: 'var(--gray-400)' }}>{i + 1}</span></td>
                  <td style={tdStyle}><a href={`mailto:${r.email}`} style={{ color: 'var(--navy)', fontSize: 14, fontWeight: 500 }}>{r.email}</a></td>
                  <td style={tdStyle}><span style={{ fontSize: 13.5, color: 'var(--gray-600)' }}>{r.name || '—'}</span></td>
                  <td style={tdStyle}><span style={{ fontSize: 12.5, color: 'var(--gray-400)' }}>{new Date(r.subscribed_at).toLocaleDateString()}</span></td>
                  <td style={tdStyle}>
                    <span style={{ background: r.active ? '#dcfce7' : '#f1f5f9', color: r.active ? '#16a34a' : '#94a3b8', fontSize: 11.5, fontWeight: 700, padding: '3px 10px', borderRadius: 20 }}>
                      {r.active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td style={tdStyle}>
                    <button onClick={() => del(r.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 15, color: 'var(--gray-400)', padding: 4, borderRadius: 4 }}>🗑</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

const pageTitle = { fontFamily: 'Syne,sans-serif', fontSize: 26, fontWeight: 800, color: 'var(--navy)' };
const pageSub = { color: 'var(--gray-400)', fontSize: 14, marginTop: 4 };
const thStyle = { padding: '11px 16px', fontSize: 11.5, fontWeight: 700, color: 'var(--gray-400)', textTransform: 'uppercase', letterSpacing: '.05em', textAlign: 'left' };
const tdStyle = { padding: '11px 16px' };
