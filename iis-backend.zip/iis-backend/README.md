# IIS LTD — Full-Stack Backend

**Identity Insight Solution Ltd** — Node.js + React backend and admin dashboard for the IIS LTD website.

---

## 📁 Project Structure

```
iis-backend/
├── server/              ← Node.js + Express API
│   ├── index.js         ← Entry point
│   ├── db.js            ← SQLite database setup
│   ├── .env             ← Environment variables
│   ├── middleware/
│   │   └── auth.js      ← JWT authentication middleware
│   └── routes/
│       ├── auth.js      ← Login / change password
│       ├── contact.js   ← Contact form + page view tracking
│       ├── enquiries.js ← Enquiry management (CRUD)
│       └── admin.js     ← Dashboard stats, users, subscribers
│
├── client/              ← React admin dashboard
│   ├── src/
│   │   ├── App.jsx
│   │   ├── contexts/
│   │   │   └── AuthContext.jsx
│   │   ├── components/
│   │   │   └── Layout.jsx   ← Sidebar + topbar shell
│   │   └── pages/
│   │       ├── Login.jsx
│   │       ├── Dashboard.jsx   ← Charts & stats
│   │       ├── Enquiries.jsx   ← Manage contact form submissions
│   │       ├── Subscribers.jsx ← Newsletter subscribers
│   │       └── Settings.jsx    ← Password + user management
│   └── vite.config.js
│
└── main.js              ← ⭐ Drop-in replacement for your website's main.js
```

---

## 🚀 Quick Start

### 1. Install & start the server

```bash
cd server
npm install
npm start
# Server runs on http://localhost:5000
```

### 2. Install & start the admin dashboard

```bash
cd client
npm install
npm run dev
# Dashboard runs on http://localhost:3000
```

### 3. Connect your website

Replace your existing `main.js` with the `main.js` file at the root of this project.
That's it — your contact form will now POST to the backend.

---

## 🔐 Default Login

| Username | Password       |
|----------|----------------|
| admin    | Admin@IIS2026  |

> ⚠️ **Change this password immediately after first login** via Settings → Change Password.

---

## 📡 API Endpoints

### Public (no auth required)
| Method | Endpoint                  | Description                        |
|--------|---------------------------|------------------------------------|
| POST   | `/api/contact`            | Submit contact form                |
| POST   | `/api/contact/subscribe`  | Newsletter subscribe               |
| POST   | `/api/contact/pageview`   | Track a page view                  |
| GET    | `/api/health`             | Health check                       |

### Auth
| Method | Endpoint                    | Description             |
|--------|-----------------------------|-------------------------|
| POST   | `/api/auth/login`           | Admin login             |
| GET    | `/api/auth/me`              | Get current user        |
| POST   | `/api/auth/change-password` | Change password         |

### Protected (Bearer token required)
| Method | Endpoint                          | Description                  |
|--------|-----------------------------------|------------------------------|
| GET    | `/api/enquiries`                  | List enquiries (filterable)  |
| GET    | `/api/enquiries/:id`              | Single enquiry               |
| PATCH  | `/api/enquiries/:id/status`       | Update enquiry status        |
| DELETE | `/api/enquiries/:id`              | Delete enquiry               |
| GET    | `/api/admin/stats`                | Dashboard statistics         |
| GET    | `/api/admin/subscribers`          | List newsletter subscribers  |
| DELETE | `/api/admin/subscribers/:id`      | Remove subscriber            |
| GET    | `/api/admin/users`                | List admin users             |
| POST   | `/api/admin/users`                | Create admin user            |
| DELETE | `/api/admin/users/:id`            | Delete admin user            |

---

## 🎛️ Admin Dashboard Features

- **Dashboard** — Live stats, enquiries over time (line chart), enquiries by service (pie chart), page views bar chart
- **Enquiries** — Full CRUD, search, filter by status (new / in_progress / replied / closed), click-to-expand detail panel with direct email/WhatsApp reply buttons
- **Subscribers** — View, search, and export newsletter subscribers as CSV
- **Settings** — Change your password, manage admin users, view API reference

---

## 🗄️ Database (SQLite)

No external database needed. A file `iis.db` is auto-created in `server/` on first run.

**Tables:**
- `enquiries` — Contact form submissions
- `subscribers` — Newsletter sign-ups
- `admin_users` — Dashboard admin accounts
- `page_views` — Website analytics

---

## ⚙️ Environment Variables (`server/.env`)

```env
PORT=5000
JWT_SECRET=change-this-to-a-long-random-string
CLIENT_URL=http://localhost:3000

# Optional: SMTP for email notifications
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@gmail.com
SMTP_PASS=your-app-password
NOTIFY_EMAIL=info@identityinsight.co.ke
```

---

## 🌐 Deploying to Production

1. **Server:** Deploy to Railway, Render, or a VPS. Set `NODE_ENV=production` and a strong `JWT_SECRET`.
2. **Client:** Run `npm run build` in `/client`, serve the `dist/` folder via nginx or Vercel.
3. **Website:** Update `API_BASE` in `main.js` to your production server URL.
4. **Database:** For high-traffic, migrate to PostgreSQL by swapping `sqlite3` for `pg` and updating `db.js`.

---

## 📞 IIS LTD Contact

- 📍 Taita Taveta County, Kenya
- 📞 +254 790 218 788
- ✉️ info@identityinsight.co.ke
