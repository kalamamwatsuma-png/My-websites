const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcryptjs');

const DB_PATH = path.join(__dirname, 'iis.db');

let db;

function getDB() {
  if (!db) {
    db = new sqlite3.Database(DB_PATH);
  }
  return db;
}

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    getDB().run(sql, params, function (err) {
      if (err) reject(err);
      else resolve({ lastID: this.lastID, changes: this.changes });
    });
  });
}

function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    getDB().all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    getDB().get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

async function initDB() {
  console.log('📦 Initializing SQLite database...');

  // Enquiries / Contact form submissions
  await run(`
    CREATE TABLE IF NOT EXISTS enquiries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT,
      service TEXT,
      message TEXT NOT NULL,
      status TEXT DEFAULT 'new',
      ip_address TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Newsletter subscribers
  await run(`
    CREATE TABLE IF NOT EXISTS subscribers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      name TEXT,
      subscribed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      active INTEGER DEFAULT 1
    )
  `);

  // Admin users
  await run(`
    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT DEFAULT 'admin',
      last_login DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Page views / analytics
  await run(`
    CREATE TABLE IF NOT EXISTS page_views (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      page TEXT NOT NULL,
      ip_address TEXT,
      user_agent TEXT,
      referrer TEXT,
      viewed_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Seed default admin if not exists
  const existing = await get('SELECT id FROM admin_users WHERE username = ?', ['admin']);
  if (!existing) {
    const hash = await bcrypt.hash('Admin@IIS2026', 10);
    await run(
      'INSERT INTO admin_users (username, email, password_hash, role) VALUES (?, ?, ?, ?)',
      ['admin', 'admin@identityinsight.co.ke', hash, 'superadmin']
    );
    console.log('👤 Default admin created: admin / Admin@IIS2026');
  }

  // Seed some demo enquiries
  const count = await get('SELECT COUNT(*) as cnt FROM enquiries');
  if (count.cnt === 0) {
    const demos = [
      ['James Mwangi', 'james@example.com', '+254722000001', 'Workforce Deployment & Outsourcing', 'We need 5 trained cashiers for our supermarket in Voi.', 'new'],
      ['Grace Kilonzo', 'grace@school.ac.ke', '+254733000002', 'Training & Capacity Building', 'Looking for ICT teachers for our secondary school.', 'replied'],
      ['Peter Kamau', 'peter@farm.co.ke', '+254744000003', 'Workforce Deployment & Outsourcing', 'Need seasonal farm workers for the upcoming harvest.', 'new'],
      ['Sarah Ndunge', 'sarah@sme.co.ke', '+254755000004', 'SME & Institutional Support', 'We are a small bakery and need production assistants.', 'closed'],
    ];
    for (const d of demos) {
      await run(
        'INSERT INTO enquiries (name, email, phone, service, message, status) VALUES (?,?,?,?,?,?)',
        d
      );
    }
    console.log('📝 Demo enquiries seeded');
  }

  console.log('✅ Database ready');
}

module.exports = { getDB, run, all, get, initDB };
