const express = require('express');
const { all, get, run } = require('../db');
const { authMiddleware } = require('../middleware/auth');
const bcrypt = require('bcryptjs');

const router = express.Router();
router.use(authMiddleware);

// GET /api/admin/stats - dashboard overview
router.get('/stats', async (req, res) => {
  try {
    const [
      totalEnquiries, newEnquiries, repliedEnquiries, closedEnquiries,
      totalSubscribers, totalPageViews,
      recentEnquiries, topPages, enquiriesByService, enquiriesByDay
    ] = await Promise.all([
      get('SELECT COUNT(*) as cnt FROM enquiries'),
      get("SELECT COUNT(*) as cnt FROM enquiries WHERE status = 'new'"),
      get("SELECT COUNT(*) as cnt FROM enquiries WHERE status = 'replied'"),
      get("SELECT COUNT(*) as cnt FROM enquiries WHERE status = 'closed'"),
      get('SELECT COUNT(*) as cnt FROM subscribers WHERE active = 1'),
      get('SELECT COUNT(*) as cnt FROM page_views'),
      all('SELECT * FROM enquiries ORDER BY created_at DESC LIMIT 5'),
      all(`SELECT page, COUNT(*) as views FROM page_views 
           WHERE page != 'contact_form_submit'
           GROUP BY page ORDER BY views DESC LIMIT 6`),
      all(`SELECT COALESCE(service, 'General Enquiry') as service, COUNT(*) as count 
           FROM enquiries GROUP BY service ORDER BY count DESC`),
      all(`SELECT DATE(created_at) as date, COUNT(*) as count 
           FROM enquiries 
           WHERE created_at >= DATE('now', '-30 days')
           GROUP BY DATE(created_at) ORDER BY date ASC`)
    ]);

    res.json({
      summary: {
        total: totalEnquiries.cnt,
        new: newEnquiries.cnt,
        replied: repliedEnquiries.cnt,
        closed: closedEnquiries.cnt,
        subscribers: totalSubscribers.cnt,
        pageViews: totalPageViews.cnt,
      },
      recentEnquiries,
      topPages,
      enquiriesByService,
      enquiriesByDay
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch stats.' });
  }
});

// GET /api/admin/subscribers
router.get('/subscribers', async (req, res) => {
  const rows = await all('SELECT * FROM subscribers ORDER BY subscribed_at DESC');
  res.json(rows);
});

// DELETE /api/admin/subscribers/:id
router.delete('/subscribers/:id', async (req, res) => {
  await run('DELETE FROM subscribers WHERE id = ?', [req.params.id]);
  res.json({ success: true });
});

// GET /api/admin/users
router.get('/users', async (req, res) => {
  const rows = await all('SELECT id, username, email, role, last_login, created_at FROM admin_users');
  res.json(rows);
});

// POST /api/admin/users - create new admin
router.post('/users', async (req, res) => {
  const { username, email, password, role } = req.body;
  if (!username || !email || !password) {
    return res.status(400).json({ error: 'Username, email and password required.' });
  }
  try {
    const hash = await bcrypt.hash(password, 10);
    const result = await run(
      'INSERT INTO admin_users (username, email, password_hash, role) VALUES (?, ?, ?, ?)',
      [username, email, hash, role || 'admin']
    );
    res.status(201).json({ id: result.lastID, username, email, role: role || 'admin' });
  } catch (err) {
    if (err.message.includes('UNIQUE')) {
      return res.status(409).json({ error: 'Username or email already exists.' });
    }
    res.status(500).json({ error: 'Failed to create user.' });
  }
});

// DELETE /api/admin/users/:id
router.delete('/users/:id', async (req, res) => {
  if (parseInt(req.params.id) === req.user.id) {
    return res.status(400).json({ error: 'Cannot delete your own account.' });
  }
  await run('DELETE FROM admin_users WHERE id = ?', [req.params.id]);
  res.json({ success: true });
});

module.exports = router;
