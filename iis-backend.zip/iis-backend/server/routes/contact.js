const express = require('express');
const { body, validationResult } = require('express-validator');
const { run } = require('../db');

const router = express.Router();

// POST /api/contact
router.post('/',
  [
    body('name').trim().notEmpty().withMessage('Name is required').isLength({ max: 100 }),
    body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
    body('message').trim().notEmpty().withMessage('Message is required').isLength({ max: 2000 }),
    body('phone').optional().trim().isLength({ max: 20 }),
    body('service').optional().trim().isLength({ max: 100 }),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.array() });
    }

    const { name, email, phone, service, message } = req.body;
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;

    try {
      const result = await run(
        `INSERT INTO enquiries (name, email, phone, service, message, ip_address, status)
         VALUES (?, ?, ?, ?, ?, ?, 'new')`,
        [name, email, phone || null, service || null, message, ip]
      );

      // Log page analytics
      await run(
        `INSERT INTO page_views (page, ip_address, referrer) VALUES ('contact_form_submit', ?, ?)`,
        [ip, req.headers.referer || null]
      );

      console.log(`📬 New enquiry #${result.lastID} from ${name} <${email}>`);

      res.status(201).json({
        success: true,
        message: "Thank you! We'll respond within 24 hours.",
        id: result.lastID
      });
    } catch (err) {
      console.error('Contact form error:', err);
      res.status(500).json({ error: 'Failed to submit enquiry. Please try again.' });
    }
  }
);

// POST /api/contact/subscribe (newsletter)
router.post('/subscribe',
  [body('email').isEmail().normalizeEmail()],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ error: 'Valid email required.' });
    }
    const { email, name } = req.body;
    try {
      await run(
        'INSERT OR IGNORE INTO subscribers (email, name) VALUES (?, ?)',
        [email, name || null]
      );
      res.json({ success: true, message: 'Subscribed successfully!' });
    } catch (err) {
      res.status(500).json({ error: 'Subscription failed.' });
    }
  }
);

// POST /api/contact/pageview
router.post('/pageview', async (req, res) => {
  const { page } = req.body;
  if (!page) return res.status(400).json({ error: 'Page required.' });
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  try {
    await run(
      'INSERT INTO page_views (page, ip_address, user_agent, referrer) VALUES (?, ?, ?, ?)',
      [page, ip, req.headers['user-agent'] || null, req.headers.referer || null]
    );
    res.json({ ok: true });
  } catch {
    res.json({ ok: false });
  }
});

module.exports = router;
