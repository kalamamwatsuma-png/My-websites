const express = require('express');
const { all, get, run } = require('../db');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

// All routes require authentication
router.use(authMiddleware);

// GET /api/enquiries - list all with filters
router.get('/', async (req, res) => {
  const { status, search, page = 1, limit = 20 } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);
  let where = [];
  let params = [];

  if (status && status !== 'all') {
    where.push('status = ?');
    params.push(status);
  }
  if (search) {
    where.push('(name LIKE ? OR email LIKE ? OR message LIKE ? OR service LIKE ?)');
    const s = `%${search}%`;
    params.push(s, s, s, s);
  }

  const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';

  try {
    const total = await get(`SELECT COUNT(*) as cnt FROM enquiries ${whereClause}`, params);
    const rows = await all(
      `SELECT * FROM enquiries ${whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );
    res.json({ enquiries: rows, total: total.cnt, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch enquiries.' });
  }
});

// GET /api/enquiries/:id
router.get('/:id', async (req, res) => {
  const row = await get('SELECT * FROM enquiries WHERE id = ?', [req.params.id]);
  if (!row) return res.status(404).json({ error: 'Enquiry not found.' });
  res.json(row);
});

// PATCH /api/enquiries/:id/status
router.patch('/:id/status', async (req, res) => {
  const { status } = req.body;
  const valid = ['new', 'in_progress', 'replied', 'closed'];
  if (!valid.includes(status)) {
    return res.status(400).json({ error: `Status must be one of: ${valid.join(', ')}` });
  }
  await run(
    'UPDATE enquiries SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
    [status, req.params.id]
  );
  res.json({ success: true, status });
});

// DELETE /api/enquiries/:id
router.delete('/:id', async (req, res) => {
  await run('DELETE FROM enquiries WHERE id = ?', [req.params.id]);
  res.json({ success: true });
});

module.exports = router;
